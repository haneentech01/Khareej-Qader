import 'package:flutter/material.dart';
import 'package:mahmoud/screens/account_screen.dart';
import 'package:mahmoud/screens/cart_screen.dart';
import 'package:mahmoud/screens/home_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/orders_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true),
      home: const SplashScreen(),
      routes: {
        '/home': (context) => const HomeScreen(),
        '/orders': (context) => const OrdersScreen(),
        '/cart': (context) => const CartScreen(),
        '/account': (context) => const AccountScreen(),
      },
    );
  }
}
