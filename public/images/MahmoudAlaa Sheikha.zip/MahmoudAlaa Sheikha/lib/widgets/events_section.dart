import 'package:flutter/material.dart';
import '../models/event_model.dart';
import 'event_card.dart';

class EventsSection extends StatelessWidget {
  const EventsSection({super.key});

  @override
  Widget build(BuildContext context) {
    final List<EventModel> events = [
      EventModel(
        title: 'New Music Event on Dubai Botek for Valentine Day',
        category: 'Service Category',
        location: 'Riyadh, Marash Tower',
        price: 500,
        rating: 4.5,
        hostName: 'Mohammed R.',
        hostItems: '+50 Item',
        hostAvatarPath: 'assets/images/person.png',
        imageUrl: 'assets/images/event_1.png',
      ),
      EventModel(
        title: 'Exclusive Wedding Hall Celebration',
        category: 'Venue Booking',
        location: 'Riyadh, Kingdom Centre',
        price: 1200,
        rating: 4.8,
        hostName: 'Khalid A.',
        hostItems: '+10 Item',
        hostAvatarPath: 'assets/images/person.png',
        imageUrl: 'assets/images/event_1.png',
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: events
            .map((ev) => Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: EventCard(event: ev),
                ))
            .toList(),
      ),
    );
  }
}
