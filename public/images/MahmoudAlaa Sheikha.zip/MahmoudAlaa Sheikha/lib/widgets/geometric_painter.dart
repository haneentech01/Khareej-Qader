import 'package:flutter/material.dart';

class GeometricPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFD4AF37)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final fillPaint = Paint()
      ..color = const Color(0xFFD4AF37).withOpacity(0.3)
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final iconSize = size.width * 0.35;

    final path1 = Path()
      ..moveTo(center.dx, center.dy - iconSize * 0.6)
      ..lineTo(center.dx - iconSize * 0.5, center.dy + iconSize * 0.3)
      ..lineTo(center.dx + iconSize * 0.5, center.dy + iconSize * 0.3)
      ..close();

    canvas.drawPath(path1, fillPaint);
    canvas.drawPath(path1, paint);

    final path2 = Path()
      ..moveTo(center.dx, center.dy + iconSize * 0.6)
      ..lineTo(center.dx - iconSize * 0.5, center.dy - iconSize * 0.3)
      ..lineTo(center.dx + iconSize * 0.5, center.dy - iconSize * 0.3)
      ..close();

    canvas.drawPath(path2, fillPaint);
    canvas.drawPath(path2, paint);

    canvas.drawCircle(
        center, iconSize * 0.12, Paint()..color = const Color(0xFFD4AF37));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
