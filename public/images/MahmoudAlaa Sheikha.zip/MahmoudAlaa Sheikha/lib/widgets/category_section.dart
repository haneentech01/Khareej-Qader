import 'package:flutter/material.dart';
import '../models/category_model.dart';
import 'app_colors.dart';

class CategorySection extends StatelessWidget {
  const CategorySection({Key? key}) : super(key: key);

  // Use the local assets discovered.
  static final List<CategoryModel> categories = [
    CategoryModel(title: 'Halls', iconPath: 'assets/images/halls.png'),
    CategoryModel(title: 'Musics', iconPath: 'assets/images/musics.png'),
    CategoryModel(title: 'Meals', iconPath: 'assets/images/meals.png'),
    CategoryModel(title: 'Musics', iconPath: 'assets/images/musics.png'),
    CategoryModel(title: 'Halls', iconPath: 'assets/images/halls.png'),
    CategoryModel(title: 'Meals', iconPath: 'assets/images/meals.png'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 95,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final cat = categories[index];
          return Container(
            width: 85,
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: AppColors.primaryGold.withOpacity(0.3), width: 1),
              boxShadow: [
                BoxShadow(
                    color: AppColors.primaryGold.withOpacity(0.12),
                    blurRadius: 12,
                    offset: const Offset(0, 5)),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  cat.iconPath,
                  width: 36,
                  height: 36,
                  errorBuilder: (context, error, stackTrace) => const Icon(
                      Icons.image_not_supported,
                      size: 30,
                      color: AppColors.textGrey),
                ),
                const SizedBox(height: 8),
                Text(cat.title,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textDark)),
              ],
            ),
          );
        },
      ),
    );
  }
}
