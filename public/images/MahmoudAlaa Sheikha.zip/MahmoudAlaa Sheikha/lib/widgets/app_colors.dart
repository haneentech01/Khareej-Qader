import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryGold = Color(0xFFAF8344);
  static const Color primaryGoldStart = Color(0xFFAF8344);
  static const Color primaryGoldEnd = Color(0xFFE9C75E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF1E1E1E);
  static const Color textGrey = Color(0xFF888888);
  static const Color navDark = Color(0xFF222222);
  static const Color priceTagDark = Color(0xFF2A2A2A);
}
