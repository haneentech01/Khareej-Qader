import 'package:flutter/material.dart';
import 'app_colors.dart';

class CustomBottomNav extends StatelessWidget {
  const CustomBottomNav({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 12,
        top: 14,
      ),
      decoration: const BoxDecoration(color: AppColors.navDark),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: const [
          _NavBarItem(
              icon: Icons.grid_view_rounded, title: 'Home', isSelected: true),
          _NavBarItem(
              icon: Icons.receipt_long_outlined,
              title: 'Orders',
              isSelected: false),
          _NavBarItem(
              icon: Icons.shopping_cart_outlined,
              title: 'Cart',
              isSelected: false),
          _NavBarItem(
              icon: Icons.person_outline, title: 'Account', isSelected: false),
        ],
      ),
    );
  }
}

class _NavBarItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool isSelected;

  const _NavBarItem({
    super.key,
    required this.icon,
    required this.title,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    final Color itemColor =
        isSelected ? AppColors.primaryGold : AppColors.white;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: itemColor, size: 26),
        const SizedBox(height: 4),
        Text(title,
            style: TextStyle(
                color: itemColor,
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400)),
      ],
    );
  }
}
