import 'event_model.dart';

class CartItem {
  final EventModel event;
  final bool isAvailable;

  CartItem({
    required this.event,
    this.isAvailable = true,
  });
}
