class EventModel {
  final String title;
  final String category;
  final String location;
  final double price;
  final double rating;
  final String hostName;
  final String hostItems;
  final String hostAvatarPath;
  final String imageUrl;

  EventModel({
    required this.title,
    required this.category,
    required this.location,
    required this.price,
    required this.rating,
    required this.hostName,
    required this.hostItems,
    required this.hostAvatarPath,
    required this.imageUrl,
  });
}
