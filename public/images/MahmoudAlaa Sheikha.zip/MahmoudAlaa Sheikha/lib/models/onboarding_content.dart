class OnboardingPage {
  final String title;
  final String description;
  final String illustrationTag;
  const OnboardingPage({
    required this.title,
    required this.description,
    required this.illustrationTag,
  });
}

const List<OnboardingPage> onboardingPages = [
  OnboardingPage(
    title: 'EVENTS COLLECTION',
    description: 'Discover the best things to do this week in your city.',
    illustrationTag: 'discover',
  ),
  OnboardingPage(
    title: 'Book Your Tickets Fast',
    description: 'Reserve your spot in seconds and get instant confirmation.',
    illustrationTag: 'book',
  ),
  OnboardingPage(
    title: 'Never Miss a Moment',
    description: 'Get reminders and updates for all your upcoming events.',
    illustrationTag: 'remind',
  ),
];
