import 'package:flutter/material.dart';
import 'package:mahmoud/screens/HomeContent.dart';
import 'package:mahmoud/screens/account_screen.dart';
import 'package:mahmoud/screens/cart_screen.dart';
import 'package:mahmoud/screens/orders_screen.dart';
import 'package:mahmoud/widgets/app_bottom_nav_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: IndexedStack(
        index: _navIndex,
        children: const [
          HomeContent(),
          OrdersScreen(),
          CartScreen(),
          AccountScreen(),
        ],
      ),
      bottomNavigationBar: AppBottomNavBar(
        currentIndex: _navIndex,
        onTap: (i) {
          setState(() {
            _navIndex = i;
          });
        },
      ),
    );
  }
}
