import 'package:flutter/cupertino.dart';
import 'package:mahmoud/widgets/category_section.dart';
import 'package:mahmoud/widgets/events_section.dart';
import 'package:mahmoud/widgets/home_header.dart';

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        HomeHeader(),
        SizedBox(height: 16),
        CategorySection(),
        SizedBox(height: 24),
        EventsSection(),
      ],
    );
  }
}
